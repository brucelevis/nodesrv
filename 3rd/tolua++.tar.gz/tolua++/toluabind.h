/*
** Lua binding: tolua
** Generated automatically by tolua++-1.0.91 on Wed Apr 26 22:30:15 2006.
*/

/* Exported function */
TOLUA_API int  tolua_tolua_open (lua_State* tolua_S);

